Run:
npx create-react-app
npm install react-router-dom
npm install
npm install react-helmet

Then:
copy the files provided in this github into the file
npm start

After development server opens, view the logo on the home page. It should display.
Then go to:

%PUBLIC_URL%/services/pc-building

the logo will not work properly