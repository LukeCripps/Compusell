import React from 'react';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

//Components
import Header from './components/header/Header';
import Footer from './components/footer/Footer';

//Pages
import HomeScreen from './pages/general/Home';
import AboutScreen from './pages/general/About';

//Services
import PCBuildingScreen from './pages/services/PCBuilding';
import PCPartsScreen from './pages/services/PCParts';
import PCRepairScreen from './pages/services/PCRepair';

//Store
import StoreScreen from './pages/store/Store';
import PartsScreen from './pages/store/PartsStore';
import PrebuiltStoreScreen from './pages/store/PrebuiltStore';

function App() {
  return (
    <div>
      <Router>
        <Header />
        <Routes>
          <Route exact path="/" element={<HomeScreen />} />
          <Route exact path="/pc-building" element={<PCBuildingScreen />} />
          <Route
            exact
            path="/services/parts-picker"
            element={<PCPartsScreen />}
          />
          <Route
            exact
            path="/services/pc-repairs"
            element={<PCRepairScreen />}
          />
          <Route exact path="/store" element={<StoreScreen />} />
          <Route exact path="/store/parts" element={<PartsScreen />} />
          <Route
            exact
            path="/store/prebuilts"
            element={<PrebuiltStoreScreen />}
          />
          <Route exact path="/about" element={<AboutScreen />} />
        </Routes>
        <Footer />
      </Router>
    </div>
  );
}

export default App;
