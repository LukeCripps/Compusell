import React from 'react';
import './CSS/PrebuiltStore.css';

const PrebuiltStoreScreen = () => {
  return <div>PrebuiltStore</div>;
};

export default PrebuiltStoreScreen;
