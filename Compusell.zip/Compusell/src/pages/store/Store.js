import React from 'react';
import './CSS/Store.css';

const StoreScreen = () => {
  return <div>Store</div>;
};

export default StoreScreen;
