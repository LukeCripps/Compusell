import React from 'react';
import './CSS/PartsStore.css';

const PartsStoreScreen = () => {
  return <div>PartsStore</div>;
};

export default PartsStoreScreen;
