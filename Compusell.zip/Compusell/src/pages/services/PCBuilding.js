import React from 'react';
import './CSS/PCBuilding.css';

const PCBuildingScreen = () => {
  return <div>PCBuilding</div>;
};

export default PCBuildingScreen;
