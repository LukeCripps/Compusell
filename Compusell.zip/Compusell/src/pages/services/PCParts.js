import React from 'react';
import './CSS/PCParts.css';

const PCPartsScreen = () => {
  return <div>PCParts</div>;
};

export default PCPartsScreen;
