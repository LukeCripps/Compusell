import React from 'react';
import './CSS/PCRepair.css';

const PCRepairScreen = () => {
  return <div>PCRepair</div>;
};

export default PCRepairScreen;
