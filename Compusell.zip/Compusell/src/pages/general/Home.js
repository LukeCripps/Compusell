import React from 'react';
import './CSS/home.css';
import Helmet from 'react-helmet';

const HomeScreen = () => {
  return (
    <div class="body">
      <Helmet>
        <title>CompuSell | Home</title>
      </Helmet>
      <a href="hello">Hello</a>
    </div>
  );
};

export default HomeScreen;
