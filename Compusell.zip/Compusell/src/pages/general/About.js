import React from 'react';
import './CSS/about.css';
import Helmet from 'react-helmet';

const AboutScreen = () => {
  return (
    <div>
      <Helmet>
        <title>CompuSell | About</title>
      </Helmet>
      About
    </div>
  );
};

export default AboutScreen;
