import React from 'react';
import './footer.css';

const Footer = () => {
  return (
    <div class="footer">
      <div class="innerfooter">
        <div class="quicklinks">
          <ul>
            <li class="quickitems">
              <a href="/">Home</a>
            </li>
            <li class="quickitems">
              <a href="/services/pc-building">Custom PC Building</a>
            </li>
            <li class="quickitems">
              <a href="/services/parts-picker">PC Parts List</a>
            </li>
            <li class="quickitems">
              <a href="/store">Store</a>
            </li>
            <li class="quickitems">
              <a href="/about">About Us</a>
            </li>
            <li class="quickitems">
              <a href="mailto:contact@compusell.com">Contact</a>
            </li>
          </ul>
        </div>
      </div>
      <div class="outerfooter">
        Copyright &copy; CompuSell 2021. All Rights Reserved.{' '}
        <a href="/tos">Terms of Service</a>
      </div>
    </div>
  );
};

export default Footer;
