import React from 'react';
import './header.css';

const Header = () => {
  return (
    <div class="header">
      <div class="innerHeader">
        <div class="logo">
          <a href="/">
            <img src="./img/Logo/Logo.jpg" alt="logo" />
          </a>
        </div>
        <div class="navBar">
          <input type="checkbox" class="toggler" />
          <div class="hamburger">
            <div></div>
          </div>
          <div class="menu">
            <div>
              <div>
                <ul>
                  <li>
                    <a href="/">Home</a>
                  </li>
                  <li>
                    <a href="/services/pc-building">Custom PC Building</a>
                  </li>
                  <li>
                    <a href="/services/parts-picker">PC Parts List</a>
                  </li>
                  <li>
                    <a href="/services/pc-repairs">PC Repairs</a>
                  </li>
                  <li>
                    <a href="/store">Store</a>
                  </li>
                  <li>
                    <a href="/about">About US</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
